-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: charity_system
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oid` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `problem` varchar(250) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `image` varchar(45) DEFAULT NULL,
  `document` varchar(45) DEFAULT NULL,
  `need_money` double DEFAULT NULL,
  `raise_money` double DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'1','Sumit Kumar','Cancer','India, Mumabi','pic1.jpg','SQL Interview Questions.pdf',5000,500,'Approved'),(2,'1','Nisha Kumar','Brain Problem','Mumbai','Screenshot (31).png','pic1.jpg',2000,0,'Rejected'),(3,'2','shobha patil','Brain Problem','Hadapsar ,pune','needy1.jpg','pan card.jpg',2500,1500,'Approved'),(4,'3','Disha Sharma','Brain Problem','MG road, Kothrud Pune Maharashtra','needy3.jpg','3ass.PNG',45000,2500,'Approved'),(5,'3','Jivan Jadhav','for education','Madhav Bag, Alibag','needy4.jpg','pan card.jpg',10000,650,'Approved'),(6,'3','Radha Joshi','Cancer','Devgiri nagar , Satpur Maharashtra','needy1.jpg','201_java_ass1.docx',35000,0,'Pending'),(7,'3','Ram Patil','for education','North Hudko, Nashik ','needy2.png','inline.JPG',20000,0,'Approved'),(8,'1','Sumita Kumar','Brain Problem','Hadapsar Pune Maharashtra','needy6.jpg','1.PNG',40000,0,'Pending'),(9,'3','Bhumi Sharama','Covid -19','Satvik Nagar , Belgum Karnatak','needy6.jpg','listofprogram.docx',45000,2350,'Approved'),(10,'1','pratiksha wagh','Brain Problem','pune','needy3.jpg','3ass.PNG',2500,0,'Pending'),(11,'3','om badhan','Brain Problem','sinhgad road pune','needy4.jpg','4.PNG',50000,0,'Approved');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-23 13:47:04
